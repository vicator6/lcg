<?php

/**
 * Class LPR_Certificate
 */
class LPR_Certificate {
	/**
	 * Constructor
	 */
	function __construct() {
		$this->defines();
		$this->includes();
		add_action( 'init', array( $this, 'register_post_type' ) );
		add_action( 'add_meta_boxes', array( $this, 'add_meta_boxes' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ) );
		add_action( 'admin_footer', array( $this, 'admin_js_template' ) );
		add_action( 'save_post', array( $this, 'update_cert' ) );

		add_action( 'wp_ajax_cert_load_settings', array( $this, 'cert_load_settings' ) );
		add_action( 'wp_ajax_cert_load_preview', array( $this, 'cert_load_preview' ) );
		add_action( 'wp_ajax_cert_save_layer', array( $this, 'cert_save_layer' ) );

		add_filter( 'learn_press_course_settings_meta_box_args', array( $this, 'add_fields_to_meta_box' ) );

		add_filter( 'courses_manage_course_settings_fields', array( $this, 'xxx' ) );
	}

	function xxx( $fields ) {
		$fields[] = array(
			'name' => __( 'Select Certificate', 'meta-box' ),
			'id'   => "_lpr_course_certificate",
			'type' => 'text'
		);
		return $fields;
	}

	/**
	 * Define common const used by Certificate
	 */
	function defines() {
		define( 'LPR_CERTIFICATE_CPT', 'lpr_certificate' );
		define( 'LPR_CERTIFICATE_SLUG', 'certificate' );
		define( 'LPR_CERTIFICATE_TYPE_SLUG', 'certificate-type' );
	}

	/**
	 * Include common files
	 */
	function includes() {
		require_once( LPR_CERTIFICATE_PATH . '/incs/class-lpr-certificate-helper.php' );
		require_once( LPR_CERTIFICATE_PATH . '/incs/class-lpr-certificate-field.php' );
	}

	/**
	 * Register Certificate post type
	 */
	function register_post_type() {
		register_post_type( LPR_CERTIFICATE_CPT,
			array(
				'labels'             => array(
					'name'          => __( 'Certificate', 'learn_press' ),
					'menu_name'     => __( 'Certificates', 'learn_press' ),
					'singular_name' => __( 'Certificate', 'learn_press' ),
					'add_new_item'  => __( 'Add New Certificate', 'learn_press' ),
					'edit_item'     => __( 'Edit Certificate', 'learn_press' ),
					'all_items'     => __( 'Certificates', 'learn_press' ),
				),
				'public'             => false,
				'publicly_queryable' => true,
				'show_ui'            => true,
				'has_archive'        => true,
				'capability_type'    => LPR_COURSE_CPT,
				'map_meta_cap'       => true,
				'show_in_menu'       => 'learn_press',
				'show_in_admin_bar'  => true,
				'show_in_nav_menus'  => true,
				'supports'           => array(
					'title',
					'author'
				),
				'rewrite'            => array( 'slug' => LPR_CERTIFICATE_SLUG ),
				'map_meta_cap'       => true,
			)
		);
	}

	/**
	 * Add more fields to certificate meta box
	 *
	 * @param $meta_box
	 *
	 * @return mixed
	 */
	function add_fields_to_meta_box( $meta_box ) {
		$prefix               = '_lpr_';
		$meta_box['fields'][] = array(
			'name' => __( 'Select Certificate', 'meta-box' ),
			'id'   => "{$prefix}course_certificate",
			'type' => 'text'
		);
		return $meta_box;
	}

	/**
	 * Add meta box to certificate screen
	 */
	function add_meta_boxes() {
		add_meta_box(
			'lpr_certificate_designer',
			__( 'Certificate Design', 'learn_press' ),
			array( $this, 'certificate_form' ),
			'lpr_certificate',
			'normal',
			'high'
		);

		/*add_meta_box(
			'lpr_certificate_fields',
			__( 'Certificate Fields', 'learn_press' ),
			array( $this, 'metabox_certificate_fields' ),
			'lpr_certificate',
			'side',
			'default'
		);*/
	}

	/**
	 * Meta box design form
	 */
	function certificate_form() {
		echo '<div id="certificate"></div>';
	}

	/**
	 * Admin js template
	 */
	function admin_js_template() {
		require_once LPR_CERTIFICATE_PATH . '/incs/js-template.php';
	}

	/**
	 * Load certificate settings
	 */
	function cert_load_settings() {
		$response = array();
		$data     = $_POST['data'];
		$field    = LPR_Certificate_Field::instance( $data );
		if ( $field ) {
			$response['html'] = $field->output_options( false );
			$response['name'] = $field->get_human_name();
		}
		wp_send_json( $response );
		die();
	}

	/**
	 * Load certificate preview
	 */
	function cert_load_preview() {
		$id        = !empty( $_POST['cert_id'] ) ? $_POST['cert_id'] : 0;
		$cert_data = $this->get_cert_data( $id );
		wp_send_json( $cert_data );
	}

	function cert_save_layer() {
		$post_id = !empty( $_POST['cert_id'] ) ? $_POST['cert_id'] : 0;
		$data    = !empty( $_POST['data'] ) ? $_POST['data'] : 0;

		$cert_data = get_post_meta( $post_id, '_lpr_cert', true );
		if ( $data['layers'] ) foreach ( $data['layers'] as $k => $layer ) {
			$cert_data['layers'][$k] = (object) $layer;
		}
		$cert_data['preview'] = $data['preview'];


		$cert_data            = LPR_Certificate_Helper::validate_json( $cert_data );
		update_post_meta( $post_id, '_lpr_cert', $cert_data );

		die();
	}

	/**
	 * @return mixed
	 */
	function certificate_fields() {
		$defaults = array(
			'fullname'     => array(
				'name'     => 'full_name',
				'title'    => 'Full name',
				'desc'     => __( 'The full name of an user' ),
				'variable' => 'fullname',
				'func'     => '',
				'class'    => 'dashicons-admin-users'
			),
			'course_name'  => array(
				'name'     => 'course_name',
				'title'    => 'Course name',
				'desc'     => __( 'The birth of date of an user' ),
				'variable' => 'course_name',
				'func'     => ''
			),
			'start_date'   => array(
				'name'     => 'start_date',
				'title'    => 'Start date',
				'desc'     => __( 'The birth of date of an user' ),
				'variable' => 'start_date',
				'func'     => ''
			),
			'end_date'     => array(
				'name'     => 'end_date',
				'title'    => 'End date',
				'desc'     => __( 'The birth of date of an user' ),
				'variable' => 'end_date',
				'func'     => ''
			),
			'current_date' => array(
				'name'     => 'current_date',
				'title'    => 'Current date',
				'desc'     => __( 'The birth of date of an user' ),
				'variable' => 'current_date',
				'func'     => ''
			),
			'current_time' => array(
				'name'     => 'current_time',
				'title'    => 'Current time',
				'desc'     => __( 'The birth of date of an user' ),
				'variable' => 'current_time',
				'func'     => ''
			),
			'custom'       => array(
				'name'     => 'custom',
				'title'    => 'Custom',
				'desc'     => __( 'The birth of date of an user' ),
				'variable' => '',
				'func'     => ''
			)
		);
		return apply_filters( 'lpr_certificate_fields', $defaults );
	}

	/**
	 * Admin scripts and styles
	 */
	function admin_enqueue_scripts() {
		global $pagenow;

		$dependencies = array( 'jquery', 'jquery-ui-sortable', 'jquery-ui-draggable', 'jquery-ui-droppable', 'jquery-ui-slider', 'backbone', 'underscore', 'wp-color-picker' );

		wp_register_style( 'certificate', plugins_url( '/assets/css/admin-certificate.css', LPR_CERTIFICATE_FILE ) );

		wp_register_script( 'webfont', '//ajax.googleapis.com/ajax/libs/webfont/1.4.7/webfont.js' );
		wp_register_script( 'certificate', plugins_url( '/assets/js/admin-certificate.js', LPR_CERTIFICATE_FILE ), $dependencies );
		wp_register_script( 'fabric-js', plugins_url( '/assets/js/fabric.js', LPR_CERTIFICATE_FILE ) );
		wp_register_script( 'certificate-selector', plugins_url( '/assets/js/certificate-selector.js', LPR_CERTIFICATE_FILE ), array(
			'jquery', 'backbone', 'underscore'
		) );
		// ensure we are in edit certificate
		if ( in_array( $pagenow, array( 'post.php', 'post-new.php' ) ) ) {
			if ( 'lpr_certificate' == get_post_type() ) {
				wp_enqueue_style( 'wp-color-picker' );
				wp_enqueue_style( 'certificate' );

				wp_enqueue_script( 'certificate' );
				wp_enqueue_script( 'fabric-js' );
				wp_enqueue_script( 'webfont' );

				wp_enqueue_media();
			} elseif ( 'lpr_course' == get_post_type() ) {
				wp_enqueue_style( 'certificate' );

				wp_enqueue_script( 'fabric-js' );
				wp_enqueue_script( 'webfont' );
				wp_enqueue_script( 'certificate-selector' );
			}
		}
	}

	/**
	 * Update cert data
	 *
	 * @param $post_id
	 *
	 * @return mixed
	 */
	function update_cert( $post_id ) {
		if ( 'lpr_certificate' != get_post_type( $post_id ) ) {
			return $post_id;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return $post_id;
		}

		/*if ( ! current_user_can( 'edit_post' ) ) {
			return $post_id;
		}*/

		if ( !empty( $_POST['cert'] ) ) {
			$data   = $_POST['cert'];
			$layers = json_decode( stripslashes( $data['layers'] ) );
			if ( $layers ) foreach ( $layers as $k => $layer ) {
				foreach ( $layer as $k2 => $option ) {
					if ( is_string( $option ) && strlen( $option ) && ( preg_match( '!color!i', $k2 ) || $k2 == 'fill' ) ) {
						$layers[$k]->$k2 = LPR_Certificate_Helper::rgb_to_hex( $option );
					}
				}
			}
			$data['layers'] = $layers;
			$data['preview'] = $this->generate_preview( $data['id'], $data['preview'] );
			update_post_meta( $post_id, '_lpr_cert', $data );
		}
	}

	function generate_preview( $id, $data ){
		$wp_upload_dir = LPR_Certificate_Helper::get_certificate_path();
		$file_name = '_certificate_preview_' . $id . '.png';
		$file = $wp_upload_dir['path'] . '/' . $file_name;
		$content = preg_replace( '!^data:image/png;base64,!', '', $data );
		LPR_Certificate_Helper::filesystem()->put_contents ( $file, base64_decode( $content ) );
		return  $file_name;
	}

	function get_cert_data( $post_id = null ) {
		if ( !$post_id ) {
			global $post;
			if ( $post ) {
				$post_id = $post->ID;
			}
		}
		$data = (array) get_post_meta( $post_id, '_lpr_cert', true );

		if ( $data ) {
			if ( !empty( $data['id'] ) ) {
				$data['url'] = wp_get_attachment_url( $data['id'] );
			}
			if( !empty( $data['preview'] ) ){
				$upload_dir = LPR_Certificate_Helper::get_certificate_path();
				$data['preview'] = $upload_dir['url'] . '/' . $data['preview'];
			}
		}
		$data['ajax']    = admin_url( 'admin-ajax.php' );
		$data['post_id'] = $post_id;
		return $data;
	}

	/**
	 * Create a default certificate if there are not any certificates in the system
	 */
	static function create_default_certificate() {
		if ( !get_posts( array( 'post_type' => 'lpr_certificate', 'post_status' => 'publish' ) ) ) {
			$source_file = LPR_CERTIFICATE_PATH . '/assets/images/certificate.jpg';
			if ( $upload_file = self::upload_certificate( $source_file ) ) {
				try {
					$cert_id = wp_insert_post(
						array(
							'post_type'   => 'lpr_certificate',
							'post_title'  => __( 'Default Template', 'learn_press_certificates' ),
							'post_status' => 'publish'
						)
					);

					$filetype = wp_check_filetype( basename( $upload_file['file'] ), null );

					// Prepare an array of post data for the attachment.
					$attachment = array(
						'guid'           => $upload_file['url'] . '/' . 'certificate-template.jpg',
						'post_mime_type' => $filetype['type'],
						'post_title'     => preg_replace( '/\.[^.]+$/', '', 'certificate-template.jpg' ),
						'post_content'   => '',
						'post_status'    => 'inherit'
					);

					// Insert the attachment.
					$attach_id = wp_insert_attachment( $attachment, $upload_file['file'], 0 );

					// Make sure that this file is included, as wp_generate_attachment_metadata() depends on it.
					require_once( ABSPATH . 'wp-admin/includes/image.php' );

					// Generate the metadata for the attachment, and update the database record.
					$attach_data = wp_generate_attachment_metadata( $attach_id, $upload_file['file'] );
					wp_update_attachment_metadata( $attach_id, $attach_data );

					$cert       = maybe_unserialize( @file_get_contents( LPR_CERTIFICATE_PATH . '/incs/cert.tmpl' ) );
					$cert['id'] = $attach_id;
					update_post_meta( $cert_id, '_lpr_cert', $cert );
				} catch ( Exception $ex ) {
				}
			} else {
			}
		}

	}

	static function upload_certificate( $source_file ) {
		if ( !function_exists( 'wp_handle_upload' ) ) {
			require_once( ABSPATH . 'wp-admin/includes/file.php' );
		}
		$file = dirname( $source_file ) .'/certificate-template.jpg';
		@copy( $source_file, $file );
		$file = file_exists( $file ) ? $file : $source_file;
		$uploadedfile     = array(
			'tmp_name' => $file,
			'name'     => 'certificate-template.jpg',
			'size'	=> filesize( $file )
		);
		$upload_overrides = array(
			'test_form' => false,
			'test_size' => false,
			'action'    => 'certificate_upload'
		);

		$movefile      = wp_handle_upload( $uploadedfile, $upload_overrides );

		if ( $movefile && !isset( $movefile['error'] ) ) {
			return $movefile;
		} else {
			/**
			 * Error generated by _wp_handle_upload()
			 * @see _wp_handle_upload() in wp-admin/includes/file.php
			 */


			return false;
		}
	}
}