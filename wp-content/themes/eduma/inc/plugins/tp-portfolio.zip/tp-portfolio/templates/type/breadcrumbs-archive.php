<div class="top_site_main">
	<div class="container page-title-wrapper">
		<div class="page-title-captions">
			<header class="entry-header">
				<h2 class="entry-title">
					<?php
					echo single_cat_title();
					?>
				</h2>
			</header>
		</div>
		<div class="breadcrumbs">
			<?php
			echo thim_portfolio_breadcrumbs();
			?>
		</div>
	</div>
</div>