<?php
/**
 * Place the function will be deprecated or may not used here
 */
