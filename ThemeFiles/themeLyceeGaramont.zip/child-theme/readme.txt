/* EDUMA CHILD THEME 1.0.0 */

-- Notes --

+ When active this child theme, please go to menu Appearance / Customize
then try to save changes one more time to flush styles on whole site.

+ In case you made some changes in Eduma Parent theme and you want to keep them for
the child theme, please follow the guide:
-> Go to menu Appearance / Customize.
-> Change Active theme to Eduma. Find section Import/Export then export settings.
-> Change Active theme to Eduma Child. Go to section Import/Export then import the exported file.
-> Save changes.

Any questions about child theme, feel free to discuss with our support team at https://thimpress.com/forums/forum/eduma/.

If you like the theme and our product please leave us a ★★★★★ rating at http://themeforest.net/downloads.
A huge thank you from ThimPress Team in advance!


