<?php

$courses = $titan->createThimCustomizerSection( array(
	'name'     => esc_html__('LearnPress', 'eduma'),
	'position' => 70,
	'id'       => 'learnpress',
) );
