<div class="course-introduce">

	<?php the_excerpt();?>

</div>
