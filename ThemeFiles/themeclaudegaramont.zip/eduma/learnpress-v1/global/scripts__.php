<script type="text/javascript">
	jQuery(function(){
		<?php echo $code;?>
	});
</script>
