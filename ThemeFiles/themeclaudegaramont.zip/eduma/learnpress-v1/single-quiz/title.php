<?php
/**
 * Single quiz title
 *
 * @author  ThimPress
 * @package LearnPress/Templates
 * @version 1.0
 */

if ( !defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>

<h1 class="quiz-title entry-title"><?php the_title(); ?></h1>
