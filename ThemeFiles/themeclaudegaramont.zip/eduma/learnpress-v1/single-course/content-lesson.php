<?php
/**
 * @author        ThimPress
 * @package       LearnPress/Templates
 * @version       1.0
 */

defined( 'ABSPATH' ) || exit();
?>
	<div id="learn-press-course-lesson">
		<?php do_action( 'learn_press_course_content_lesson' ); ?>
	</div>

<?php

return;
/**
 * @author        ThimPress
 * @package       LearnPress/Templates
 * @version       1.0
 */

defined( 'ABSPATH' ) || exit();
?>
<?php do_action( 'learn_press_course_content_lesson' ); ?>